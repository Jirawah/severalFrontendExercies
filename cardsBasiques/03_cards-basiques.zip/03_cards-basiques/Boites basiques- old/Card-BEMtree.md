Wrapper
    Wrapper-card 
    --> .portrait
    --> .promo   
        Wrapper-card-img
        Wrapper-card-desc
            Wrapper-card-name
            Wrapper-card-price
